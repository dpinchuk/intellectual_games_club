export default {
    table: '.table'
}