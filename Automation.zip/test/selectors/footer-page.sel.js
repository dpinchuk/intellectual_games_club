export default {
    footer: '#footer',
    footerText: '#copyright-text',
    footerVersionText: '#version-text',
    copyrightText: '#info-text',
    copyrightSize: '1rem',
    appVersionColor: '#version-text',
    appVersionSize: '0.5rem'
}