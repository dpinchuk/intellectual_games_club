export default {
    textWelcome: '#text-welcome',
    btnContinue: '#btn-continue'
}