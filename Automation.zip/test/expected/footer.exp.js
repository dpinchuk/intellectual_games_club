export default {
    footerBgColor: 'rgba(0,0,0,0.03)',
    footerTextName: '© Intellectual Games Club Sacramento',
    footerVersionTextName: 'Version',
    copyrightTextColor: 'rgba(33,37,41,1)',
    copyrightTextSize: '16px',
    appVersionColor: 'rgba(33,37,41,1)',
    appVersionSize: '8px'
}