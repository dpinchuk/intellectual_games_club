export default {
    moderLogin: 'moderator',
    moderPass: 'moder@1234',
    testLogin: 'test',
    testPass: 'test@1234'
}